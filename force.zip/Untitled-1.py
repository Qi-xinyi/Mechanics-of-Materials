import pandas as pd

df = pd.read_csv("D:\\材料力学\\程序\\luoyining.csv")
